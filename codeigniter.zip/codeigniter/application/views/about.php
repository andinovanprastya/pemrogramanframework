<!DOCTYPE html>
<html lang="">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>About Me</title>

		<!-- Bootstrap CSS -->
		<link rel="stylesheet" href= "<?php echo base_url('')?>asset/css/bootstrap.min.css">

		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<nav class="navbar navbar-default" role="navigation">
			<div class="container-fluid">
				<!-- Brand and toggle get grouped for better mobile display -->
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="<?php echo site_url()?>/home">andi.net</a>
				</div>

		
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-ex1-collapse">
					<ul class="nav navbar-nav">
						<li><a href="<?php echo site_url()?>/home">Home</a></li>
						<li class="active"><a href="<?php echo site_url()?>/about">About</a></li>
						<li><a href="<?php echo site_url()?>/contact">Contact</a></li>
					</ul>
					<form class="navbar-form navbar-right" role="search">
						<div class="form-group">
							<input type="text" class="form-control" placeholder="Cari apa?">
						</div>
						<button type="submit" class="btn btn-default">Cari</button>
						ID
					</form>
				</div><!-- /.navbar-collapse -->
			</div>
		</nav>


		<div class="container-fluid">
			
			<div class="row">
			  <div class="col-md-4">
			    <div class="thumbnail">
			      <a href="<?php echo site_url()?>/home">
			        <img src="<?php echo base_url()?>asset/image/andi.jpg" alt="Lights" style="width:100%">			       
			      </a>
			    </div>
			  </div>
			  <div class="col-md-4">
			    <div class="thumbnail">			      
			        <div class="caption">
			        	<h4>
			        	<table id="t01">						  
						  <tr>
						    <td>Nama</td>
						    <td>&nbsp&nbsp&nbsp</td>
						    <td>Andi Novan Prastya</td>						    
						  </tr>
						  <tr>
						    <td>NIM</td>
						    <td>&nbsp&nbsp&nbsp</td>
						    <td>1541180105</td>						    
						  </tr>
						  <tr>
						    <td>Kelas</td>
						    <td>&nbsp&nbsp&nbsp</td>
						    <td>TI-2A</td>						    
						  </tr>
						  <tr>
						    <td>Prodi</td>
						    <td>&nbsp&nbsp&nbsp</td>
						    <td>Teknik Informatika</td>						    
						  </tr>
						  <tr>
						    <td>Jurusan</td>
						    <td>&nbsp&nbsp&nbsp</td>
						    <td>Teknologi Informasi</td>						    
						  </tr>
						  <tr>
						    <td>Alamat</td>
						    <td>&nbsp&nbsp&nbsp</td>
						    <td>Jalan Semanggi Barat 16A Malang</td>						    
						  </tr>
						  <tr>
						    <td>No HP</td>
						    <td>&nbsp&nbsp&nbsp</td>
						    <td>081556664663</td>						    
						  </tr>						  
						</table>
						</h4>
			        </div>
			    </div>
			  </div>
			  
			</div>

		</div>
			</center>
			

		</div>

	<!-- jQuery -->
		<script src="//code.jquery.com/jquery.js"></script>
		<!-- Bootstrap JavaScript -->
		<script src="<?php echo base_url('')?>asset/js/bootstrap.min.js"></script>
		<!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
 		<script src="Hello World"></script>
	</body>
</html>